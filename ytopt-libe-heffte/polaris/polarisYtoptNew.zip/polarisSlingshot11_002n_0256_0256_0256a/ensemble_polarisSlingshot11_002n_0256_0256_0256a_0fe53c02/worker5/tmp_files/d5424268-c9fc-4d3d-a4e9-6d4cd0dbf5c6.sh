#!/bin/bash -x

speed3d_r2c cufft double 256 256 256 -reorder -a2a -pencils -r2c_dir 2 -ingrid 8 1 1 -outgrid 1 4 2  -n5
