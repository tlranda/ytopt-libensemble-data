#!/bin/bash -x

speed3d_r2c cufft double 256 256 256 -reorder -p2p_pl -slabs -r2c_dir 0 -ingrid 1 1 8 -outgrid 2 4 1  -n5
