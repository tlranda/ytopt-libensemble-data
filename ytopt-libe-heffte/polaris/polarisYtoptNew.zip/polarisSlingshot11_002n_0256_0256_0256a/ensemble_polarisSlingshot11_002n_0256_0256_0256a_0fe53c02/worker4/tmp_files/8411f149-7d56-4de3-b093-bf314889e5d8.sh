#!/bin/bash -x

speed3d_r2c cufft double 256 256 256 -no-reorder -p2p_pl -slabs -r2c_dir 2 -ingrid 2 4 1 -outgrid 1 8 1  -n5
