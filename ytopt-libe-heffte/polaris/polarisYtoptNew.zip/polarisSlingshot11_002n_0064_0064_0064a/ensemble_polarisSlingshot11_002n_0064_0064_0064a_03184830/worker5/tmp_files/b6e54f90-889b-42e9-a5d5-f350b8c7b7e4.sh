#!/bin/bash -x

speed3d_r2c cufft float 64 64 64 -reorder -a2av -pencils -r2c_dir 1 -ingrid 4 1 2 -outgrid 1 8 1  -n5
