#!/bin/bash -x

speed3d_r2c cufft float 64 64 64 -no-reorder -a2av -pencils -r2c_dir 1 -ingrid 1 2 4 -outgrid 4 1 2  -n5
