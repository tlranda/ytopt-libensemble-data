#!/bin/bash -x

speed3d_r2c cufft float 64 64 64 -no-reorder -a2av -slabs -r2c_dir 0 -ingrid 1 2 4 -outgrid 2 4 1  -n5
