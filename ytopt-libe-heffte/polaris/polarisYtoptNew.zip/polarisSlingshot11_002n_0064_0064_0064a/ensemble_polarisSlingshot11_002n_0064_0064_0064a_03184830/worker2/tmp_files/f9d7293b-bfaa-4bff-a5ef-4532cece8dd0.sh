#!/bin/bash -x

speed3d_r2c cufft float 64 64 64 -reorder -p2p_pl -pencils -r2c_dir 1 -ingrid 1 8 1 -outgrid 1 2 4  -n5
