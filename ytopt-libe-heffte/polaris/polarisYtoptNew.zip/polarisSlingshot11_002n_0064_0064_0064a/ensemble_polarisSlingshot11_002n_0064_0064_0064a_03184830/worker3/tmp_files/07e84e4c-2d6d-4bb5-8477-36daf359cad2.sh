#!/bin/bash -x

speed3d_r2c cufft float 64 64 64 -no-reorder -p2p_pl -slabs -r2c_dir 1 -ingrid 1 1 8 -outgrid 4 2 1  -n5
