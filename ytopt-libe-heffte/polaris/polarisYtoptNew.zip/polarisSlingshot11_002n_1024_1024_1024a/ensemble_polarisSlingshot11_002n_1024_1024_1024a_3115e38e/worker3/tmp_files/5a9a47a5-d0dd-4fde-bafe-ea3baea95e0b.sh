#!/bin/bash -x

speed3d_r2c cufft float-long 1024 1024 1024 -no-reorder -p2p_pl -pencils -r2c_dir 2 -ingrid 1 8 1 -outgrid 2 1 4 -no-gpu-aware -n5
