#!/bin/bash -x

speed3d_r2c cufft float-long 1024 1024 1024 -reorder -a2av -slabs -r2c_dir 0 -ingrid 2 2 2 -outgrid 2 1 4 -no-gpu-aware -n5
